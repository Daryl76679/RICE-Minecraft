package net.mcreator.rice.procedures;

import java.util.Map;

public class RiceSproutBlockUpdateTick2Procedure {

	public static void executeProcedure(Map<String, Object> dependencies) {

	}
}
