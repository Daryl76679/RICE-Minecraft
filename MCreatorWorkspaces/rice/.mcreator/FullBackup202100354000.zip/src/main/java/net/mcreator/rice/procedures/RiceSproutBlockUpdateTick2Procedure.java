package net.mcreator.rice.procedures;

public class RiceSproutBlockUpdateTick2Procedure {
	public static void execute() {
	}
}
