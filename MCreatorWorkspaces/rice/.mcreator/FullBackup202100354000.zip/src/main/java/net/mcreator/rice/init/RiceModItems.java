
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.rice.init;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.RegistryEvent;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.BlockItem;

import net.mcreator.rice.item.WaterBowlWithRiceItem;
import net.mcreator.rice.item.WaterBowlItem;
import net.mcreator.rice.item.UnprocessedRiceItem;
import net.mcreator.rice.item.RiceStemItem;
import net.mcreator.rice.item.RiceBowlItem;
import net.mcreator.rice.item.RawBrownRiceItem;
import net.mcreator.rice.item.MortarAndPestleItem;
import net.mcreator.rice.item.HarvestedRiceItem;
import net.mcreator.rice.item.GrainFlailItem;

import java.util.List;
import java.util.ArrayList;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class RiceModItems {
	private static final List<Item> REGISTRY = new ArrayList<>();
	public static final Item RICE = register(RiceModBlocks.RICE, CreativeModeTab.TAB_DECORATIONS);
	public static final Item UNPROCESSED_RICE = register(new UnprocessedRiceItem());
	public static final Item RICE_STEM = register(new RiceStemItem());
	public static final Item SECOND_STATE = register(RiceModBlocks.SECOND_STATE, CreativeModeTab.TAB_DECORATIONS);
	public static final Item THIRD_STATE = register(RiceModBlocks.THIRD_STATE, CreativeModeTab.TAB_DECORATIONS);
	public static final Item HARVESTED_RICE = register(new HarvestedRiceItem());
	public static final Item GRAIN_FLAIL = register(new GrainFlailItem());
	public static final Item RICE_SPROUT_BLOCK = register(RiceModBlocks.RICE_SPROUT_BLOCK, CreativeModeTab.TAB_DECORATIONS);
	public static final Item RICE_SPROUT_SECOND_STATE = register(RiceModBlocks.RICE_SPROUT_SECOND_STATE, null);
	public static final Item RICE_SPROUT_THIRD_STATE = register(RiceModBlocks.RICE_SPROUT_THIRD_STATE, null);
	public static final Item TEST = register(RiceModBlocks.TEST, null);
	public static final Item RICE_SPROUT_TOP = register(RiceModBlocks.RICE_SPROUT_TOP, null);
	public static final Item CULTIVATED_RICE_BASE = register(RiceModBlocks.CULTIVATED_RICE_BASE, null);
	public static final Item CULTIVATED_RICE_TOP = register(RiceModBlocks.CULTIVATED_RICE_TOP, null);
	public static final Item WATER_BOWL = register(new WaterBowlItem());
	public static final Item WATER_BOWL_WITH_RICE = register(new WaterBowlWithRiceItem());
	public static final Item RICE_BOWL = register(new RiceBowlItem());
	public static final Item RAW_BROWN_RICE = register(new RawBrownRiceItem());
	public static final Item MORTAR_AND_PESTLE = register(new MortarAndPestleItem());

	private static Item register(Item item) {
		REGISTRY.add(item);
		return item;
	}

	private static Item register(Block block, CreativeModeTab tab) {
		return register(new BlockItem(block, new Item.Properties().tab(tab)).setRegistryName(block.getRegistryName()));
	}

	@SubscribeEvent
	public static void registerItems(RegistryEvent.Register<Item> event) {
		event.getRegistry().registerAll(REGISTRY.toArray(new Item[0]));
	}
}
