
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.rice.init;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.RegistryEvent;

import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.Block;

import net.mcreator.rice.block.entity.TestBlockEntity;
import net.mcreator.rice.block.entity.SecondStateBlockEntity;
import net.mcreator.rice.block.entity.RiceSproutTopBlockEntity;
import net.mcreator.rice.block.entity.RiceSproutThirdStateBlockEntity;
import net.mcreator.rice.block.entity.RiceSproutSecondStateBlockEntity;
import net.mcreator.rice.block.entity.RiceSproutBlockBlockEntity;
import net.mcreator.rice.block.entity.CultivatedRiceTopBlockEntity;
import net.mcreator.rice.block.entity.CultivatedRiceBaseBlockEntity;

import java.util.List;
import java.util.ArrayList;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class RiceModBlockEntities {
	private static final List<BlockEntityType<?>> REGISTRY = new ArrayList<>();
	public static final BlockEntityType<?> SECOND_STATE = register("rice:second_state", RiceModBlocks.SECOND_STATE, SecondStateBlockEntity::new);
	public static final BlockEntityType<?> RICE_SPROUT_BLOCK = register("rice:rice_sprout_block", RiceModBlocks.RICE_SPROUT_BLOCK,
			RiceSproutBlockBlockEntity::new);
	public static final BlockEntityType<?> RICE_SPROUT_SECOND_STATE = register("rice:rice_sprout_second_state",
			RiceModBlocks.RICE_SPROUT_SECOND_STATE, RiceSproutSecondStateBlockEntity::new);
	public static final BlockEntityType<?> RICE_SPROUT_THIRD_STATE = register("rice:rice_sprout_third_state", RiceModBlocks.RICE_SPROUT_THIRD_STATE,
			RiceSproutThirdStateBlockEntity::new);
	public static final BlockEntityType<?> TEST = register("rice:test", RiceModBlocks.TEST, TestBlockEntity::new);
	public static final BlockEntityType<?> RICE_SPROUT_TOP = register("rice:rice_sprout_top", RiceModBlocks.RICE_SPROUT_TOP,
			RiceSproutTopBlockEntity::new);
	public static final BlockEntityType<?> CULTIVATED_RICE_BASE = register("rice:cultivated_rice_base", RiceModBlocks.CULTIVATED_RICE_BASE,
			CultivatedRiceBaseBlockEntity::new);
	public static final BlockEntityType<?> CULTIVATED_RICE_TOP = register("rice:cultivated_rice_top", RiceModBlocks.CULTIVATED_RICE_TOP,
			CultivatedRiceTopBlockEntity::new);

	private static BlockEntityType<?> register(String registryname, Block block, BlockEntityType.BlockEntitySupplier<?> supplier) {
		BlockEntityType<?> blockEntityType = BlockEntityType.Builder.of(supplier, block).build(null).setRegistryName(registryname);
		REGISTRY.add(blockEntityType);
		return blockEntityType;
	}

	@SubscribeEvent
	public static void registerTileEntity(RegistryEvent.Register<BlockEntityType<?>> event) {
		event.getRegistry().registerAll(REGISTRY.toArray(new BlockEntityType[0]));
	}
}
