
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.rice.init;

import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.RegistryEvent;
import net.minecraftforge.api.distmarker.Dist;

import net.minecraft.world.level.block.Block;

import net.mcreator.rice.block.ThirdStateBlock;
import net.mcreator.rice.block.TestBlock;
import net.mcreator.rice.block.SecondStateBlock;
import net.mcreator.rice.block.RiceSproutTopBlock;
import net.mcreator.rice.block.RiceSproutThirdStateBlock;
import net.mcreator.rice.block.RiceSproutSecondStateBlock;
import net.mcreator.rice.block.RiceSproutBlockBlock;
import net.mcreator.rice.block.RiceBlock;
import net.mcreator.rice.block.CultivatedRiceTopBlock;
import net.mcreator.rice.block.CultivatedRiceBaseBlock;

import java.util.List;
import java.util.ArrayList;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class RiceModBlocks {
	private static final List<Block> REGISTRY = new ArrayList<>();
	public static final Block RICE = register(new RiceBlock());
	public static final Block SECOND_STATE = register(new SecondStateBlock());
	public static final Block THIRD_STATE = register(new ThirdStateBlock());
	public static final Block RICE_SPROUT_BLOCK = register(new RiceSproutBlockBlock());
	public static final Block RICE_SPROUT_SECOND_STATE = register(new RiceSproutSecondStateBlock());
	public static final Block RICE_SPROUT_THIRD_STATE = register(new RiceSproutThirdStateBlock());
	public static final Block TEST = register(new TestBlock());
	public static final Block RICE_SPROUT_TOP = register(new RiceSproutTopBlock());
	public static final Block CULTIVATED_RICE_BASE = register(new CultivatedRiceBaseBlock());
	public static final Block CULTIVATED_RICE_TOP = register(new CultivatedRiceTopBlock());

	private static Block register(Block block) {
		REGISTRY.add(block);
		return block;
	}

	@SubscribeEvent
	public static void registerBlocks(RegistryEvent.Register<Block> event) {
		event.getRegistry().registerAll(REGISTRY.toArray(new Block[0]));
	}

	@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
	public static class ClientSideHandler {
		@SubscribeEvent
		public static void clientSetup(FMLClientSetupEvent event) {
			RiceBlock.registerRenderLayer();
			SecondStateBlock.registerRenderLayer();
			ThirdStateBlock.registerRenderLayer();
			RiceSproutBlockBlock.registerRenderLayer();
			RiceSproutSecondStateBlock.registerRenderLayer();
			RiceSproutThirdStateBlock.registerRenderLayer();
			TestBlock.registerRenderLayer();
			RiceSproutTopBlock.registerRenderLayer();
			CultivatedRiceBaseBlock.registerRenderLayer();
			CultivatedRiceTopBlock.registerRenderLayer();
		}
	}
}
