package net.mcreator.rice.procedures;

import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.Level;
import net.minecraft.core.BlockPos;

import net.mcreator.rice.init.RiceModBlocks;

public class CultivatedRiceBaseBlockAddedProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z) {
		if ((world.getFluidState(new BlockPos((int) x, (int) (y + 1), (int) z)).createLegacyBlock()).getBlock() == Blocks.VOID_AIR
				|| (world.getFluidState(new BlockPos((int) x, (int) (y + 1), (int) z)).createLegacyBlock()).getBlock() == Blocks.AIR
				|| (world.getFluidState(new BlockPos((int) x, (int) (y + 1), (int) z)).createLegacyBlock()).getBlock() == Blocks.CAVE_AIR) {
			world.setBlock(new BlockPos((int) x, (int) (y + 1), (int) z), RiceModBlocks.CULTIVATED_RICE_TOP.defaultBlockState(), 3);
		} else {
			if (world instanceof Level) {
				Block.dropResources(world.getBlockState(new BlockPos((int) x, (int) y, (int) z)), (Level) world,
						new BlockPos((int) x, (int) y, (int) z));
				world.destroyBlock(new BlockPos((int) x, (int) y, (int) z), false);
			}
		}
	}
}
